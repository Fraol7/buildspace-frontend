"use client"

import type React from "react"

import { createContext, useContext, useState, useCallback } from "react"
import type { Message } from "./chat-interface"

interface ChatContextType {
  messages: Message[]
  sendMessage: (content: string, receiverId: string) => Promise<void>
  sendFile: (file: File, receiverId: string) => Promise<void>
  retryMessage: (messageId: string) => Promise<void>
  deleteChat: (contactId: string) => void
}

const ChatContext = createContext<ChatContextType | undefined>(undefined)

export function useChatContext() {
  const context = useContext(ChatContext)
  if (!context) {
    throw new Error("useChatContext must be used within a ChatProvider")
  }
  return context
}

// Mock messages for demonstration
const mockMessages: Message[] = [
  {
    id: "1",
    content: "Hey! How's the project coming along?",
    senderId: "1",
    receiverId: "current-user",
    timestamp: new Date(Date.now() - 3600000).toISOString(),
    status: "read",
    type: "text",
  },
  {
    id: "2",
    content: "It's going well! Just finished the user interface mockups.",
    senderId: "current-user",
    receiverId: "1",
    timestamp: new Date(Date.now() - 3500000).toISOString(),
    status: "read",
    type: "text",
  },
  {
    id: "3",
    content: "That's awesome! Can't wait to see them.",
    senderId: "1",
    receiverId: "current-user",
    timestamp: new Date(Date.now() - 120000).toISOString(),
    status: "read",
    type: "text",
  },
]

export function ChatProvider({ children }: { children: React.ReactNode }) {
  const [messages, setMessages] = useState<Message[]>(mockMessages)

  const sendMessage = useCallback(async (content: string, receiverId: string): Promise<void> => {
    const newMessage: Message = {
      id: Date.now().toString(),
      content,
      senderId: "current-user",
      receiverId,
      timestamp: new Date().toISOString(),
      status: "sending",
      type: "text",
    }

    setMessages((prev) => [...prev, newMessage])

    // Simulate API call
    try {
      await new Promise((resolve) => setTimeout(resolve, 1000))

      // Simulate random failure for demonstration
      if (Math.random() < 0.1) {
        throw new Error("Network error")
      }

      setMessages((prev) =>
        prev.map((msg) => (msg.id === newMessage.id ? { ...msg, status: "delivered" as const } : msg)),
      )

      // Simulate receiving a response after a delay
      setTimeout(() => {
        const responseMessage: Message = {
          id: (Date.now() + 1).toString(),
          content: `Thanks for your message: "${content}"`,
          senderId: receiverId,
          receiverId: "current-user",
          timestamp: new Date().toISOString(),
          status: "sent",
          type: "text",
        }
        setMessages((prev) => [...prev, responseMessage])
      }, 2000)
    } catch (error) {
      setMessages((prev) => prev.map((msg) => (msg.id === newMessage.id ? { ...msg, status: "failed" as const } : msg)))
      throw error
    }
  }, [])

  const sendFile = useCallback(async (file: File, receiverId: string): Promise<void> => {
    // Create a blob URL for the file (in a real app, you'd upload to your server)
    const fileUrl = URL.createObjectURL(file)

    const newMessage: Message = {
      id: Date.now().toString(),
      content: `Shared a file: ${file.name}`,
      senderId: "current-user",
      receiverId,
      timestamp: new Date().toISOString(),
      status: "sending",
      type: "file",
      fileData: {
        name: file.name,
        size: file.size,
        type: file.type,
        url: fileUrl,
      },
    }

    setMessages((prev) => [...prev, newMessage])

    // Simulate API call for file upload
    try {
      await new Promise((resolve) => setTimeout(resolve, 2000))

      // Simulate random failure for demonstration
      if (Math.random() < 0.1) {
        throw new Error("Upload failed")
      }

      setMessages((prev) =>
        prev.map((msg) => (msg.id === newMessage.id ? { ...msg, status: "delivered" as const } : msg)),
      )
    } catch (error) {
      setMessages((prev) => prev.map((msg) => (msg.id === newMessage.id ? { ...msg, status: "failed" as const } : msg)))
      throw error
    }
  }, [])

  const retryMessage = useCallback(
    async (messageId: string): Promise<void> => {
      const message = messages.find((m) => m.id === messageId)
      if (!message) return

      setMessages((prev) => prev.map((msg) => (msg.id === messageId ? { ...msg, status: "sending" as const } : msg)))

      try {
        await new Promise((resolve) => setTimeout(resolve, 1000))

        setMessages((prev) =>
          prev.map((msg) => (msg.id === messageId ? { ...msg, status: "delivered" as const } : msg)),
        )
      } catch (error) {
        setMessages((prev) => prev.map((msg) => (msg.id === messageId ? { ...msg, status: "failed" as const } : msg)))
        throw error
      }
    },
    [messages],
  )

  const deleteChat = useCallback((contactId: string) => {
    setMessages((prev) => prev.filter((msg) => !(msg.senderId === contactId || msg.receiverId === contactId)))
  }, [])

  return (
    <ChatContext.Provider value={{ messages, sendMessage, sendFile, retryMessage, deleteChat }}>
      {children}
    </ChatContext.Provider>
  )
}
