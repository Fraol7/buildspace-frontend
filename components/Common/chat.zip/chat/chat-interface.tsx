"use client"

import { useState } from "react"
import { ContactList } from "./contact-list"
import { ChatArea } from "./chat-area"
import { ChatProvider } from "./chat-context"

export interface Contact {
  id: string
  name: string
  avatar?: string
  lastMessage?: string
  lastMessageTime?: string
  isOnline: boolean
  unreadCount: number
}

export interface Message {
  id: string
  content: string
  senderId: string
  receiverId: string
  timestamp: string
  status: "sending" | "sent" | "delivered" | "read" | "failed"
  type: "text" | "file"
  fileData?: {
    name: string
    size: number
    type: string
    url: string
  }
}

const mockContacts: Contact[] = [
  {
    id: "1",
    name: "Alice Johnson",
    lastMessage: "Hey, how's the project going?",
    lastMessageTime: "2 min ago",
    isOnline: true,
    unreadCount: 2,
  },
  {
    id: "2",
    name: "Bob Smith",
    lastMessage: "Thanks for the update!",
    lastMessageTime: "1 hour ago",
    isOnline: false,
    unreadCount: 0,
  },
  {
    id: "3",
    name: "Carol Davis",
    lastMessage: "Can we schedule a meeting?",
    lastMessageTime: "3 hours ago",
    isOnline: true,
    unreadCount: 1,
  },
  {
    id: "4",
    name: "David Wilson",
    lastMessage: "Perfect, let's do it!",
    lastMessageTime: "Yesterday",
    isOnline: false,
    unreadCount: 0,
  },
  {
    id: "5",
    name: "Alice Johnson",
    lastMessage: "Hey, how's the project going?",
    lastMessageTime: "2 min ago",
    isOnline: true,
    unreadCount: 2,
  },
  {
    id: "6",
    name: "Bob Smith",
    lastMessage: "Thanks for the update!",
    lastMessageTime: "1 hour ago",
    isOnline: false,
    unreadCount: 0,
  },
  {
    id: "7",
    name: "Carol Davis",
    lastMessage: "Can we schedule a meeting?",
    lastMessageTime: "3 hours ago",
    isOnline: true,
    unreadCount: 1,
  },
  {
    id: "8",
    name: "David Wilson",
    lastMessage: "Perfect, let's do it!",
    lastMessageTime: "Yesterday",
    isOnline: false,
    unreadCount: 0,
  },
]

export function ChatInterface() {
  const [selectedContact, setSelectedContact] = useState<Contact | null>(null)
  const [contacts, setContacts] = useState<Contact[]>(mockContacts)

  const deleteChat = (contactId: string) => {
    setContacts(contacts.filter((contact) => contact.id !== contactId))
    if (selectedContact?.id === contactId) {
      setSelectedContact(null)
    }
  }

  return (
    <ChatProvider>
      <div className="flex h-[calc(100vh-100px)] m-0">
        <div className="w-80 border-r border-gray-200 bg-white">
          <ContactList contacts={contacts} selectedContact={selectedContact} onSelectContact={setSelectedContact} />
        </div>
        <div className="flex-1">
          <ChatArea selectedContact={selectedContact} onDeleteChat={deleteChat} />
        </div>
      </div>
    </ChatProvider>
  )
}
